WeCast+ - cara membuat APK
1. Instal Android Studio (versi terbaru) dari developer.android.com/studio
2. File > Open > pilih folder WeCastPlus ini, tunggu Gradle Sync selesai (butuh internet)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK ada di app/build/outputs/apk/debug/app-debug.apk, kirim ke HP lalu instal
Catatan: proyek ini belum dikompilasi/diuji. Jika ada error build, kirim pesannya ke Claude untuk diperbaiki.
