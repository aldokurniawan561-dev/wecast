package com.wecast.plus

import android.Manifest
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent {
            MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun normUrl(s: String): String {
    val t = s.trim()
    return when {
        Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(t) -> t
        t.contains(".") && !t.contains(" ") -> "https://$t"
        else -> "https://www.google.com/search?q=" + Uri.encode(t)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var devices by remember { mutableStateOf(listOf<Device>()) }
    var sel by remember { mutableStateOf<Device?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pastikan HP dan TV terhubung ke Wi-Fi yang sama.") }
    var url by remember { mutableStateOf("https://www.netflix.com") }
    var torch by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    val web = remember {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView, u: String) { url = u; Prefs.add(ctx, "hist", u); refresh++ }
            }
            loadUrl("https://www.netflix.com")
        }
    }

    fun castUrl(u: String) {
        val d = sel ?: run { status = "Pilih TV dulu di tab Cast."; return }
        scope.launch {
            status = "Mengirim ke ${d.name}..."
            status = if (Dlna.play(d, u)) "Memutar di ${d.name}" else "Gagal mengirim. TV mungkin tidak mendukung format ini."
        }
    }

    fun castFile(uri: Uri) {
        val mime = ctx.contentResolver.getType(uri) ?: "video/mp4"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
        ContextCompat.startForegroundService(ctx, Intent(ctx, HttpServerService::class.java))
        val id = ServerHolder.register(uri, mime)
        scope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { try { ServerHolder.start(ctx) } catch (e: Exception) { } }
            castUrl("http://${Net.ip()}:${ServerHolder.PORT}/f/$id.$ext")
        }
    }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) castFile(u) }
    val projection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == android.app.Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, MirrorService::class.java).putExtra("code", r.resultCode).putExtra("data", data))
            scope.launch { kotlinx.coroutines.delay(1500); castUrl("http://${Net.ip()}:${ServerHolder.PORT}/mirror") }
        } else status = "Izin perekaman layar ditolak."
    }
    val qr = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.let { url = normUrl(it); web.loadUrl(url); tab = 1 }
    }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Cast", "Browser", "Alat").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(listOf("📡", "🌐", "🧰")[i]) }, label = { Text(t) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Cast & Mirroring", style = MaterialTheme.typography.headlineSmall)
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                    Button(enabled = !busy, onClick = {
                        busy = true; status = "Mencari TV..."
                        scope.launch { devices = Dlna.discover(ctx); busy = false; status = if (devices.isEmpty()) "TV tidak ditemukan. Aktifkan DLNA/Screen Share di TV." else "${devices.size} perangkat ditemukan." }
                    }) { Text(if (busy) "Mencari..." else "Cari TV") }
                    devices.forEach { d ->
                        Row(Modifier.fillMaxWidth().clickable { sel = d }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sel == d, onClick = { sel = d }); Text(d.name)
                        }
                    }
                    HorizontalDivider()
                    Button(enabled = sel != null, onClick = { picker.launch(arrayOf("video/*", "image/*", "audio/*")) }) { Text("Cast video / foto / musik") }
                    Button(enabled = sel != null, onClick = {
                        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        projection.launch(mpm.createScreenCaptureIntent())
                    }) { Text("Mulai screen mirroring") }
                    OutlinedButton(enabled = sel != null, onClick = {
                        ctx.startService(Intent(ctx, MirrorService::class.java).setAction("stop"))
                        sel?.let { d -> scope.launch { Dlna.stop(d); status = "Dihentikan." } }
                    }) { Text("Stop") }
                    Text("Catatan: mirroring memakai aliran MJPEG lewat Wi-Fi. TV yang hanya mendukung Miracast atau Chromecast mungkin tidak bisa menerimanya.", style = MaterialTheme.typography.bodySmall)
                }
                1 -> Column(Modifier.fillMaxSize().padding(8.dp)) {
                    var field by remember(url) { mutableStateOf(url) }
                    OutlinedTextField(field, { field = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Alamat web atau pencarian") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { web.loadUrl(normUrl(field)) }) { Text("Buka") }
                        OutlinedButton(onClick = { Prefs.add(ctx, "fav", url); refresh++ }) { Text("★") }
                        OutlinedButton(onClick = { castUrl(url) }) { Text("Cast") }
                        OutlinedButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("App") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AssistChip(onClick = { web.loadUrl("https://www.netflix.com") }, label = { Text("Netflix") })
                        AssistChip(onClick = { web.loadUrl("https://www.youtube.com") }, label = { Text("YouTube") })
                        AssistChip(onClick = { web.loadUrl("https://www.disneyplus.com") }, label = { Text("Disney+") })
                    }
                    AndroidView(factory = { web }, modifier = Modifier.fillMaxWidth().weight(1f))
                }
                else -> Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Alat", style = MaterialTheme.typography.headlineSmall)
                    Button(onClick = { qr.launch(ScanOptions().setBeepEnabled(false).setPrompt("Arahkan ke QR code")) }) { Text("Scan QR") }
                    Button(onClick = {
                        try {
                            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                            torch = !torch; cm.setTorchMode(cm.cameraIdList.first(), torch)
                        } catch (e: Exception) { status = "Senter tidak tersedia." }
                    }) { Text(if (torch) "Matikan senter" else "Nyalakan senter") }
                    HorizontalDivider()
                    key(refresh) {
                        Text("Favorit", style = MaterialTheme.typography.titleMedium)
                        Prefs.get(ctx, "fav").ifEmpty { listOf() }.forEach { u -> Text(u, Modifier.clickable { url = u; web.loadUrl(u); tab = 1 }.padding(vertical = 4.dp), maxLines = 1) }
                        Text("Riwayat", style = MaterialTheme.typography.titleMedium)
                        Prefs.get(ctx, "hist").take(20).forEach { u -> Text(u, Modifier.clickable { url = u; web.loadUrl(u); tab = 1 }.padding(vertical = 4.dp), maxLines = 1) }
                    }
                    OutlinedButton(onClick = { Prefs.put(ctx, "hist", emptyList()); refresh++ }) { Text("Hapus riwayat") }
                    Text("WeCast+ versi 1.0", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
