package com.wecast.plus

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import java.io.InputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

object Frames { @Volatile var jpeg: ByteArray? = null; @Volatile var seq = 0L; @Volatile var active = false }

class MjpegIn : InputStream() {
    private var buf = ByteArray(0); private var pos = 0; private var last = -1L
    override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) < 0) -1 else b[0].toInt() and 255 }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        while (pos >= buf.size) {
            val f = Frames.jpeg; val s = Frames.seq
            if (f == null || s == last) { if (!Frames.active) return -1; Thread.sleep(30); continue }
            last = s
            val head = "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n".toByteArray()
            buf = head + f + "\r\n".toByteArray(); pos = 0
        }
        val n = minOf(len, buf.size - pos)
        System.arraycopy(buf, pos, b, off, n); pos += n
        return n
    }
}

class MediaServer(private val ctx: Context) : NanoHTTPD(ServerHolder.PORT) {
    override fun serve(s: IHTTPSession): Response {
        if (s.uri == "/mirror") return newChunkedResponse(Response.Status.OK, "multipart/x-mixed-replace; boundary=frame", MjpegIn())
        if (s.uri.startsWith("/f/")) {
            val id = s.uri.removePrefix("/f/").substringBefore('.')
            val e = ServerHolder.files[id] ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "404")
            val afd = ctx.contentResolver.openAssetFileDescriptor(e.first, "r")
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "404")
            val len = afd.length
            val range = s.headers["range"]
            var start = 0L; var end = len - 1
            if (range != null && range.startsWith("bytes=")) {
                val p = range.removePrefix("bytes=").split("-")
                start = p[0].toLongOrNull() ?: 0L
                end = p.getOrNull(1)?.toLongOrNull() ?: end
            }
            val ins = afd.createInputStream()
            var skipped = 0L
            while (skipped < start) { val k = ins.skip(start - skipped); if (k <= 0) break; skipped += k }
            val r = newFixedLengthResponse(if (range != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK, e.second, ins, end - start + 1)
            r.addHeader("Accept-Ranges", "bytes")
            r.addHeader("transferMode.dlna.org", "Streaming")
            if (range != null) r.addHeader("Content-Range", "bytes $start-$end/$len")
            return r
        }
        return newFixedLengthResponse("WeCast+ server aktif")
    }
}

object ServerHolder {
    const val PORT = 8899
    private var server: MediaServer? = null
    val files = ConcurrentHashMap<String, Pair<Uri, String>>()
    @Synchronized fun start(ctx: Context) {
        if (server == null) server = MediaServer(ctx.applicationContext).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
    }
    @Synchronized fun stop() { server?.stop(); server = null }
    fun register(uri: Uri, mime: String): String { val id = UUID.randomUUID().toString().take(8); files[id] = uri to mime; return id }
}

object Net {
    fun ip(): String {
        try {
            for (i in Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (a in Collections.list(i.inetAddresses))
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: "127.0.0.1"
        } catch (e: Exception) { }
        return "127.0.0.1"
    }
}

object Prefs {
    fun get(c: Context, k: String): List<String> {
        val a = JSONArray(c.getSharedPreferences("wc", 0).getString(k, "[]"))
        return List(a.length()) { a.getString(it) }
    }
    fun put(c: Context, k: String, l: List<String>) { c.getSharedPreferences("wc", 0).edit().putString(k, JSONArray(l).toString()).apply() }
    fun add(c: Context, k: String, v: String, max: Int = 50) { put(c, k, (listOf(v) + get(c, k).filter { it != v }).take(max)) }
}

object Notif {
    fun show(s: Service, text: String, type: Int) {
        val nm = s.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("wc", "WeCast+", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(s, "wc").setContentTitle("WeCast+").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        ServiceCompat.startForeground(s, 1, n, type)
    }
}

class HttpServerService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        Notif.show(this, "Server media aktif", android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        Thread { try { ServerHolder.start(this) } catch (e: Exception) { } }.start()
        return START_STICKY
    }
    override fun onDestroy() { ServerHolder.stop() }
}
