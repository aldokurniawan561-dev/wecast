package com.wecast.plus

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.*

data class Device(val name: String, val control: String)

object Dlna {
    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"

    suspend fun discover(ctx: Context): List<Device> = withContext(Dispatchers.IO) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wm.createMulticastLock("wecast").apply { setReferenceCounted(false); acquire() }
        val found = LinkedHashMap<String, Device>()
        try {
            val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: $AVT\r\n\r\n").toByteArray()
            DatagramSocket().use { s ->
                s.soTimeout = 1000
                val addr = InetAddress.getByName("239.255.255.250")
                repeat(2) { s.send(DatagramPacket(msg, msg.size, addr, 1900)) }
                val end = System.currentTimeMillis() + 4000
                val buf = ByteArray(4096)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val txt = String(p.data, 0, p.length)
                        val loc = Regex("(?im)^location:\\s*(.+)$").find(txt)?.groupValues?.get(1)?.trim() ?: continue
                        if (!found.containsKey(loc)) fetch(loc)?.let { found[loc] = it }
                    } catch (e: SocketTimeoutException) { }
                }
            }
        } catch (e: Exception) { } finally { lock.release() }
        found.values.toList()
    }

    private fun fetch(loc: String): Device? = try {
        val c = URL(loc).openConnection() as HttpURLConnection
        c.connectTimeout = 3000; c.readTimeout = 3000
        val xml = c.inputStream.bufferedReader().readText()
        val name = Regex("<friendlyName>(.*?)</friendlyName>").find(xml)?.groupValues?.get(1) ?: "TV"
        val m = Regex("<serviceType>$AVT</serviceType>.*?<controlURL>(.*?)</controlURL>", RegexOption.DOT_MATCHES_ALL).find(xml)
        if (m == null) null else {
            val u = URL(loc); val path = m.groupValues[1]
            val port = if (u.port == -1) 80 else u.port
            Device(name, if (path.startsWith("http")) path else "${u.protocol}://${u.host}:$port${if (path.startsWith("/")) path else "/$path"}")
        }
    } catch (e: Exception) { null }

    private fun soap(ctl: String, action: String, body: String): Boolean {
        val env = """<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:$action xmlns:u="$AVT"><InstanceID>0</InstanceID>$body</u:$action></s:Body></s:Envelope>"""
        val c = URL(ctl).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 4000; c.readTimeout = 6000
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
        c.setRequestProperty("SOAPACTION", "\"$AVT#$action\"")
        c.outputStream.use { it.write(env.toByteArray()) }
        return c.responseCode in 200..299
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    suspend fun play(d: Device, url: String): Boolean = withContext(Dispatchers.IO) {
        try {
            soap(d.control, "SetAVTransportURI", "<CurrentURI>${esc(url)}</CurrentURI><CurrentURIMetaData></CurrentURIMetaData>") &&
                soap(d.control, "Play", "<Speed>1</Speed>")
        } catch (e: Exception) { false }
    }

    suspend fun stop(d: Device) = withContext(Dispatchers.IO) { try { soap(d.control, "Stop", "") } catch (e: Exception) { false } }
}
