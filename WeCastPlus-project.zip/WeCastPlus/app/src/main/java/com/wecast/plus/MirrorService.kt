package com.wecast.plus

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import java.io.ByteArrayOutputStream

class MirrorService : Service() {
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private val ht = HandlerThread("mirror")
    private var lastT = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i == null || i.action == "stop") { stopSelf(); return START_NOT_STICKY }
        Notif.show(this, "Screen mirroring aktif", android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        Thread { try { ServerHolder.start(this) } catch (e: Exception) { } }.start()
        @Suppress("DEPRECATION")
        val data = i.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)
        val dm = resources.displayMetrics
        val scale = 720f / maxOf(dm.widthPixels, dm.heightPixels)
        val w = (dm.widthPixels * scale).toInt(); val h = (dm.heightPixels * scale).toInt()
        ht.start(); val handler = Handler(ht.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        Frames.active = true
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastT >= 80) {
                        lastT = now
                        val p = img.planes[0]
                        val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, h, Bitmap.Config.ARGB_8888)
                        bmp.copyPixelsFromBuffer(p.buffer)
                        val out = ByteArrayOutputStream()
                        Bitmap.createBitmap(bmp, 0, 0, w, h).compress(Bitmap.CompressFormat.JPEG, 60, out)
                        Frames.jpeg = out.toByteArray(); Frames.seq++
                    }
                } finally { img.close() }
            }
        }, handler)
        vd = proj!!.createVirtualDisplay("wecast", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Frames.active = false
        vd?.release(); reader?.close(); proj?.stop(); ht.quitSafely()
    }
}
